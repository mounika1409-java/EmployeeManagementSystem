# Java Console-Based Employee Management System

## Overview
This is a simple Java console application that allows an organization to manage employee details such as ID, name, salary, and department.

## Features
- Add Employee
- View Employees
- Update Employee Details (Salary or Department)
- Delete Employee
- Calculate Net Salary after 10% tax deduction

## Technologies Used
- Java
- ArrayList
- Scanner (for user input)
- Console-based UI

## How to Run
1. Open any Java compiler or IDE (e.g., Dcoder, AIDE, Eclipse, IntelliJ).
2. Paste the `Main.java` code.
3. Run the program.
4. Follow the menu instructions to perform operations.

## Sample Menu
1. Add Employee  
2. View Employees  
3. Update Employee  
4. Delete Employee  
5. Exit

## Author
Orsu Mounika  
Email: orsumounikampc@gmail.com  
Phone: 9618995094  
LinkedIn: [View Profile](https://www.linkedin.com/in/orsu-mounika-6b35112a8)